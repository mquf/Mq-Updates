"""
Mq Tweaks - Clean PC Optimization Tool for Gaming FPS
Watermark: @mquf
Requires: Windows + Run as Administrator for full features
"""

import customtkinter as ctk
import tkinter as tk
from tkinter import messagebox, filedialog
import psutil
import platform
import subprocess
import os
import sys
import json
import webbrowser
import threading
import ctypes
import time
import hashlib
import sqlite3
import urllib.request
from pathlib import Path
from datetime import datetime
from PIL import Image, ImageTk
import io

# ==================== CONFIG ====================
APP_NAME = "Mq Tweaks"
VERSION = "2.9"
WATERMARK = "@mquf"
CONFIG_FILE = Path(os.getenv("APPDATA", ".")) / "mq_tweaks" / "config.json"
DB_FILE = Path(os.getenv("APPDATA", ".")) / "mq_tweaks" / "users.db"
PROTECTED_APPS_DEFAULT = ["Discord.exe", "explorer.exe", "chrome.exe", "msedge.exe", "Code.exe", "Steam.exe", "EpicGamesLauncher.exe"]

# Auto-update: host version.json online (GitHub raw / your site)
# Example: {"version": "3.0", "url": "https://example.com/Mq_Tweaks.exe", "notes": "Bug fixes"}
UPDATE_URL = ""  # e.g. "https://raw.githubusercontent.com/USER/REPO/main/version.json"
UPDATE_CHECK_ON_START = True

# KeyAuth — https://keyauth.win/api/1.3/
KEYAUTH_ENABLED = True
KEYAUTH_API = "https://keyauth.win/api/1.3/"
KEYAUTH_NAME = "Mq Opti"
KEYAUTH_OWNERID = "VpiHo5VpOd"
KEYAUTH_SECRET = "0606196872d34f9aac4de4d9330b99efba0ab5270941c055b536d372adb79141"
KEYAUTH_VERSION = "1.0"
_KEYAUTH_SESSION = {"sessionid": None, "initialized": False}

# Icon path (works both in script and frozen exe)
def resource_path(relative):
    if getattr(sys, "frozen", False):
        return os.path.join(sys._MEIPASS, relative)
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), relative)

ICON_PATH = resource_path(os.path.join("assets", "icon.png"))

# Power Plan GUIDs
HIGH_PERF_GUID = "8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c"
ULTIMATE_PERF_GUID = "e9a42b02-d5df-448d-aa00-03f14749eb61"

ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("dark-blue")


# ==================== UTILS ====================
def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except Exception:
        return False


def run_as_admin():
    if is_admin():
        return True
    try:
        ctypes.windll.shell32.ShellExecuteW(
            None, "runas", sys.executable, " ".join([f'"{arg}"' for arg in sys.argv]), None, 1
        )
        sys.exit(0)
    except Exception as e:
        messagebox.showerror("Error", f"Failed to elevate: {e}")
        return False


def load_config():
    CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, "r") as f:
                return json.load(f)
        except Exception:
            pass
    return {"protected_apps": PROTECTED_APPS_DEFAULT, "first_run": True}


def save_config(cfg):
    CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_FILE, "w") as f:
        json.dump(cfg, f, indent=2)


def _hash_pw(password: str) -> str:
    return hashlib.sha256(password.encode("utf-8")).hexdigest()


def init_user_db():
    """Create local user database with demo customers if empty."""
    DB_FILE.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_FILE))
    cur = conn.cursor()
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT DEFAULT 'customer',
            created_at TEXT
        )
        """
    )
    cur.execute("SELECT COUNT(*) FROM users")
    if cur.fetchone()[0] == 0:
        demo_users = [
            ("admin", "admin123", "admin"),
            ("mquf", "mquf123", "admin"),
            ("customer1", "pass123", "customer"),
            ("customer2", "pass123", "customer"),
            ("demo", "demo", "customer"),
        ]
        now = datetime.now().isoformat(timespec="seconds")
        for u, p, role in demo_users:
            cur.execute(
                "INSERT INTO users (username, password_hash, role, created_at) VALUES (?, ?, ?, ?)",
                (u, _hash_pw(p), role, now),
            )
    conn.commit()
    conn.close()


def _keyauth_request(params: dict):
    """GET request to KeyAuth API 1.3 with query params."""
    from urllib.parse import urlencode
    qs = urlencode(params)
    url = KEYAUTH_API.rstrip("/") + "/?" + qs
    req = urllib.request.Request(url, headers={"User-Agent": f"MqTweaks/{VERSION}"})
    with urllib.request.urlopen(req, timeout=10) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _keyauth_hwid():
    """Stable HWID always >= 20 chars (KeyAuth requirement)."""
    parts = []
    try:
        out = subprocess.check_output(
            "wmic csproduct get uuid", shell=True,
            creationflags=subprocess.CREATE_NO_WINDOW, stderr=subprocess.DEVNULL
        ).decode(errors="ignore")
        for line in out.splitlines():
            line = line.strip()
            if line and "UUID" not in line.upper():
                parts.append(line)
                break
    except Exception:
        pass
    try:
        parts.append(platform.node() or "")
    except Exception:
        pass
    try:
        parts.append(str(platform.processor() or ""))
    except Exception:
        pass
    try:
        parts.append(os.getenv("COMPUTERNAME", "") or os.getenv("USERNAME", ""))
    except Exception:
        pass
    raw = "|".join(p for p in parts if p) or "mq-tweaks-fallback-hwid"
    # SHA-256 hex = 64 chars — always valid for KeyAuth
    return hashlib.sha256(raw.encode("utf-8", errors="ignore")).hexdigest()


def keyauth_init():
    global _KEYAUTH_SESSION
    if _KEYAUTH_SESSION.get("initialized") and _KEYAUTH_SESSION.get("sessionid"):
        return True, "OK"
    try:
        data = _keyauth_request({
            "type": "init",
            "ver": KEYAUTH_VERSION,
            "name": KEYAUTH_NAME,
            "ownerid": KEYAUTH_OWNERID,
        })
        if not data.get("success"):
            return False, data.get("message") or "KeyAuth init failed."
        _KEYAUTH_SESSION["sessionid"] = data.get("sessionid")
        _KEYAUTH_SESSION["initialized"] = True
        return True, "OK"
    except Exception as e:
        return False, f"KeyAuth init error: {e}"


def keyauth_login(username: str, password: str):
    ok, msg = keyauth_init()
    if not ok:
        return False, msg, None
    try:
        data = _keyauth_request({
            "type": "login",
            "username": username,
            "pass": password,
            "sessionid": _KEYAUTH_SESSION["sessionid"],
            "name": KEYAUTH_NAME,
            "ownerid": KEYAUTH_OWNERID,
            "hwid": _keyauth_hwid(),
        })
        if data.get("success"):
            return True, data.get("message") or "OK", "customer"
        return False, data.get("message") or "Login failed.", None
    except Exception as e:
        return False, f"KeyAuth login error: {e}", None


def keyauth_register(username: str, password: str, license_key: str = ""):
    ok, msg = keyauth_init()
    if not ok:
        return False, msg
    license_key = (license_key or "").strip()
    if not license_key:
        return False, "License key is required to create an account."
    try:
        data = _keyauth_request({
            "type": "register",
            "username": username,
            "pass": password,
            "key": license_key,
            "sessionid": _KEYAUTH_SESSION["sessionid"],
            "name": KEYAUTH_NAME,
            "ownerid": KEYAUTH_OWNERID,
            "hwid": _keyauth_hwid(),
        })
        if data.get("success"):
            return True, data.get("message") or "Account created. You can log in now."
        return False, data.get("message") or "Register failed."
    except Exception as e:
        return False, f"KeyAuth register error: {e}"


def authenticate_user(username: str, password: str):
    """Returns (ok, message, role). Uses KeyAuth when enabled, else local SQLite."""
    username = (username or "").strip()
    password = password or ""
    if not username or not password:
        return False, "Enter username and password.", None

    if KEYAUTH_ENABLED:
        return keyauth_login(username, password)

    try:
        init_user_db()
        conn = sqlite3.connect(str(DB_FILE))
        cur = conn.cursor()
        cur.execute("SELECT password_hash, role FROM users WHERE username = ?", (username,))
        row = cur.fetchone()
        conn.close()
        if not row:
            return False, "Invalid username or password.", None
        if row[0] != _hash_pw(password):
            return False, "Invalid username or password.", None
        return True, "OK", row[1]
    except Exception as e:
        return False, f"Auth error: {e}", None


def _version_tuple(v: str):
    parts = []
    for p in (v or "0").strip().split("."):
        try:
            parts.append(int(p))
        except ValueError:
            parts.append(0)
    return tuple(parts)


def check_for_updates(silent=True):
    """
    Fetch UPDATE_URL JSON and compare versions.
    Returns dict {update: bool, version, url, notes} or None on skip/error.
    """
    if not UPDATE_URL:
        return None
    try:
        req = urllib.request.Request(
            UPDATE_URL,
            headers={"User-Agent": f"MqTweaks/{VERSION}"}
        )
        with urllib.request.urlopen(req, timeout=6) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        remote = str(data.get("version", "")).strip()
        if not remote:
            return None
        if _version_tuple(remote) > _version_tuple(VERSION):
            return {
                "update": True,
                "version": remote,
                "url": data.get("url", ""),
                "notes": data.get("notes", ""),
            }
        return {"update": False, "version": remote, "url": "", "notes": ""}
    except Exception:
        if not silent:
            return {"update": False, "error": True}
        return None


def register_user(username: str, password: str, license_key: str = ""):
    username = (username or "").strip()
    password = password or ""
    if len(username) < 3:
        return False, "Username must be at least 3 characters."
    if len(password) < 4:
        return False, "Password must be at least 4 characters."

    if KEYAUTH_ENABLED:
        return keyauth_register(username, password, license_key)

    try:
        init_user_db()
        conn = sqlite3.connect(str(DB_FILE))
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO users (username, password_hash, role, created_at) VALUES (?, ?, ?, ?)",
            (username, _hash_pw(password), "customer", datetime.now().isoformat(timespec="seconds")),
        )
        conn.commit()
        conn.close()
        return True, "Account created. You can log in now."
    except sqlite3.IntegrityError:
        return False, "Username already exists."
    except Exception as e:
        return False, str(e)


def get_gpu_info():
    """Detect GPU vendor and name as safely as possible."""
    info = {"vendor": "Unknown", "name": "Unknown", "driver": "Unknown"}
    try:
        # Try NVIDIA first
        result = subprocess.run(
            ["nvidia-smi", "--query-gpu=name,driver_version", "--format=csv,noheader"],
            capture_output=True, text=True, timeout=5, creationflags=subprocess.CREATE_NO_WINDOW
        )
        if result.returncode == 0 and result.stdout.strip():
            parts = result.stdout.strip().split(",")
            info["vendor"] = "NVIDIA"
            info["name"] = parts[0].strip()
            if len(parts) > 1:
                info["driver"] = parts[1].strip()
            return info
    except Exception:
        pass

    try:
        # WMI fallback (works for both NVIDIA and AMD)
        import wmi
        c = wmi.WMI()
        for gpu in c.Win32_VideoController():
            name = gpu.Name or ""
            if "NVIDIA" in name.upper() or "GeForce" in name.upper() or "RTX" in name.upper() or "GTX" in name.upper():
                info["vendor"] = "NVIDIA"
                info["name"] = name
                info["driver"] = gpu.DriverVersion or "Unknown"
                return info
            if "AMD" in name.upper() or "Radeon" in name.upper():
                info["vendor"] = "AMD"
                info["name"] = name
                info["driver"] = gpu.DriverVersion or "Unknown"
                return info
            if info["name"] == "Unknown":
                info["name"] = name
                info["driver"] = gpu.DriverVersion or "Unknown"
    except Exception:
        pass

    # Final fallback
    try:
        result = subprocess.run(
            ["wmic", "path", "win32_VideoController", "get", "name,DriverVersion"],
            capture_output=True, text=True, timeout=5, creationflags=subprocess.CREATE_NO_WINDOW
        )
        if result.returncode == 0:
            lines = [l.strip() for l in result.stdout.splitlines() if l.strip() and "Name" not in l]
            if lines:
                info["name"] = lines[0]
    except Exception:
        pass
    return info


def get_cpu_info():
    """Prefer a friendly CPU name over the raw platform.processor() string."""
    try:
        result = subprocess.run(
            ["wmic", "cpu", "get", "Name"],
            capture_output=True, text=True, timeout=4,
            creationflags=subprocess.CREATE_NO_WINDOW
        )
        if result.returncode == 0:
            lines = [l.strip() for l in result.stdout.splitlines() if l.strip() and "Name" not in l]
            if lines:
                return lines[0]
    except Exception:
        pass
    try:
        return platform.processor() or "Unknown CPU"
    except Exception:
        return "Unknown CPU"


def get_ram_info():
    try:
        mem = psutil.virtual_memory()
        total_gb = round(mem.total / (1024**3), 1)
        return f"{total_gb} GB"
    except Exception:
        return "Unknown"


# ==================== MAIN APP ====================
class MqufOptimizer(ctk.CTk):
    THEMES = {
        # Premium dark gaming style (OPTIUM-inspired)
        "Dark":     {"bg": "#0b0b0d", "sidebar": "#101014", "card": "#16161c", "accent": "#ff3b30", "text": "#f2f2f2"},
        "Crimson":  {"bg": "#0c0a0a", "sidebar": "#140e0e", "card": "#1c1212", "accent": "#ff2a2a", "text": "#f5f0f0"},
        "Midnight": {"bg": "#0a0a0f", "sidebar": "#0d0d14", "card": "#15151f", "accent": "#7c3aed", "text": "#e8e8ff"},
        "Blue":     {"bg": "#0a0e14", "sidebar": "#0d121a", "card": "#141c28", "accent": "#3b82f6", "text": "#eef3ff"},
        "Green":    {"bg": "#0a100e", "sidebar": "#0d1612", "card": "#132019", "accent": "#22c55e", "text": "#ecfdf5"},
    }

    def __init__(self):
        super().__init__()
        self.title(f"{APP_NAME} v{VERSION}")
        self.geometry("1040x720")
        self.minsize(960, 640)
        self.resizable(True, True)
        try:
            self.iconbitmap(default=resource_path(os.path.join("assets", "icon_256.png")))
        except Exception:
            pass
        try:
            img = Image.open(ICON_PATH)
            self.iconphoto(True, ImageTk.PhotoImage(img.resize((32, 32))))
        except Exception:
            pass

        self.config_data = load_config()
        self.current_theme = self.config_data.get("theme", "Dark")
        self.transparent = self.config_data.get("transparent", False)
        self.apply_theme_colors()
        ctk.set_appearance_mode("Dark")

        self.gpu_info = {"vendor": "...", "name": "Scanning...", "driver": "..."}
        self.cpu_name = "Scanning..."
        self.ram_info = "..."
        self.protected = set(self.config_data.get("protected_apps", PROTECTED_APPS_DEFAULT))
        self.selected_pids = set()
        self._resizing = False
        self._resize_after = None
        self._monitor_running = False

        # Center window
        self.update_idletasks()
        x = (self.winfo_screenwidth() // 2) - (1040 // 2)
        y = (self.winfo_screenheight() // 2) - (720 // 2)
        self.geometry(f"+{x}+{y}")

        # Smooth resize: pause heavy updates while dragging edges
        self.bind("<Configure>", self._on_resize)

        if self.transparent:
            self.attributes("-alpha", 0.92)

        self.current_user = None
        self.user_role = None
        init_user_db()
        # Always require login — never auto-save / auto-login
        self.config_data.pop("remember_user", None)
        self.config_data.pop("remember_role", None)
        save_config(self.config_data)
        self.show_login()

    def apply_theme_colors(self):
        t = self.THEMES.get(self.current_theme, self.THEMES["Dark"])
        self.bg_color = t["bg"]
        self.sidebar_color = t["sidebar"]
        self.card_color = t["card"]
        self.accent_color = t["accent"]
        self.text_color = t["text"]
        self.configure(fg_color=self.bg_color)

    def clear_window(self):
        for widget in self.winfo_children():
            widget.destroy()

    # ---------- LOGIN ----------
    def show_login(self):
        self.clear_window()
        frame = ctk.CTkFrame(self, fg_color=self.bg_color)
        frame.pack(fill="both", expand=True)

        ctk.CTkLabel(
            frame, text="MQ TWEAKS",
            font=ctk.CTkFont(family="Segoe UI", size=32, weight="bold"),
            text_color="#ffffff"
        ).pack(pady=(70, 4))
        ctk.CTkFrame(frame, fg_color=self.accent_color, height=3, width=110).pack(pady=(0, 8))
        ctk.CTkLabel(
            frame, text="Sign in to continue",
            font=ctk.CTkFont(family="Segoe UI", size=13),
            text_color="#888"
        ).pack(pady=(0, 24))

        card = ctk.CTkFrame(frame, fg_color=self.card_color, corner_radius=14, width=380, height=420)
        card.pack()
        card.pack_propagate(False)

        ctk.CTkLabel(card, text="Username", font=ctk.CTkFont(family="Segoe UI", size=12),
                     text_color="#aaa").pack(anchor="w", padx=28, pady=(22, 4))
        self.login_user = ctk.CTkEntry(card, width=320, height=36, placeholder_text="KeyAuth username",
                                      font=ctk.CTkFont(family="Segoe UI", size=13))
        self.login_user.pack(padx=28)

        ctk.CTkLabel(card, text="Password", font=ctk.CTkFont(family="Segoe UI", size=12),
                     text_color="#aaa").pack(anchor="w", padx=28, pady=(10, 4))
        self.login_pass = ctk.CTkEntry(card, width=320, height=36, placeholder_text="password", show="•",
                                      font=ctk.CTkFont(family="Segoe UI", size=13))
        self.login_pass.pack(padx=28)
        self.login_pass.bind("<Return>", lambda e: self.do_login())

        ctk.CTkLabel(card, text="License key  (create account only)",
                     font=ctk.CTkFont(family="Segoe UI", size=12),
                     text_color="#aaa").pack(anchor="w", padx=28, pady=(10, 4))
        self.login_key = ctk.CTkEntry(card, width=320, height=36, placeholder_text="Paste license key from KeyAuth",
                                     font=ctk.CTkFont(family="Segoe UI", size=13))
        self.login_key.pack(padx=28)

        self.login_status = ctk.CTkLabel(card, text="", font=ctk.CTkFont(family="Segoe UI", size=11),
                                        text_color="#ef4444", wraplength=300)
        self.login_status.pack(pady=(12, 0))

        ctk.CTkButton(
            card, text="Login", width=320, height=40, corner_radius=8,
            font=ctk.CTkFont(family="Segoe UI", size=14, weight="bold"),
            fg_color=self.accent_color, hover_color="#e0352b",
            command=self.do_login
        ).pack(pady=(10, 6))

        ctk.CTkButton(
            card, text="Create account", width=320, height=34, corner_radius=8,
            font=ctk.CTkFont(family="Segoe UI", size=12),
            fg_color="transparent", border_width=1, border_color="#333",
            hover_color="#1a1a1a", text_color="#ccc",
            command=self.do_register
        ).pack(pady=(0, 8))

        ctk.CTkLabel(
            frame,
            text="Login: username + password  ·  Register: username + password + license key",
            font=ctk.CTkFont(family="Segoe UI", size=11),
            text_color="#555"
        ).pack(pady=14)
        self.add_watermark(frame)

    def do_login(self):
        user = self.login_user.get()
        pw = self.login_pass.get()
        ok, msg, role = authenticate_user(user, pw)
        if not ok:
            self.login_status.configure(text=msg, text_color="#ef4444")
            return
        self.current_user = user.strip()
        self.user_role = role
        self.config_data.pop("remember_user", None)
        self.config_data.pop("remember_role", None)
        save_config(self.config_data)
        self.show_welcome()

    def do_register(self):
        user = self.login_user.get()
        pw = self.login_pass.get()
        key = self.login_key.get() if hasattr(self, "login_key") else ""
        ok, msg = register_user(user, pw, key)
        self.login_status.configure(
            text=msg,
            text_color="#22c55e" if ok else "#ef4444"
        )

    # ---------- WELCOME / LOADER ----------
    def show_welcome(self):
        self.clear_window()
        frame = ctk.CTkFrame(self, fg_color=self.bg_color)
        frame.pack(fill="both", expand=True)

        # Title
        title = ctk.CTkLabel(
            frame, text="MQ TWEAKS",
            font=ctk.CTkFont(family="Segoe UI", size=38, weight="bold"),
            text_color="#ffffff"
        )
        title.pack(pady=(90, 4))

        # Red underline accent
        accent_line = ctk.CTkFrame(frame, fg_color=self.accent_color, height=3, width=140)
        accent_line.pack(pady=(0, 18))

        sub = ctk.CTkLabel(
            frame, text="PC Optimization  •  Higher FPS",
            font=ctk.CTkFont(family="Segoe UI", size=14),
            text_color="#888888"
        )
        sub.pack(pady=(0, 36))

        # Status card
        status_card = ctk.CTkFrame(frame, fg_color=self.card_color, corner_radius=14, width=400, height=150)
        status_card.pack(pady=8)
        status_card.pack_propagate(False)

        admin_status = "Administrator  •  Active" if is_admin() else "Administrator required"
        admin_color = "#22c55e" if is_admin() else self.accent_color

        ctk.CTkLabel(
            status_card, text="Welcome",
            font=ctk.CTkFont(family="Segoe UI", size=20, weight="bold"),
            text_color="#ffffff"
        ).pack(pady=(28, 4))

        ctk.CTkLabel(
            status_card, text=admin_status,
            font=ctk.CTkFont(family="Segoe UI", size=13),
            text_color=admin_color
        ).pack(pady=2)

        ctk.CTkLabel(
            status_card, text="Scan PC  →  Apply safe optimizations",
            font=ctk.CTkFont(family="Segoe UI", size=12),
            text_color="#777"
        ).pack(pady=(8, 0))

        # Buttons
        btn_frame = ctk.CTkFrame(frame, fg_color="transparent")
        btn_frame.pack(pady=28)

        if not is_admin():
            ctk.CTkButton(
                btn_frame, text="Scan PC  •  Run as Admin",
                font=ctk.CTkFont(family="Segoe UI", size=14, weight="bold"),
                fg_color=self.accent_color, hover_color="#e0352b",
                text_color="#ffffff",
                width=250, height=44, corner_radius=10,
                command=self.elevate_and_restart
            ).pack(side="left", padx=6)

        ctk.CTkButton(
            btn_frame, text="Continue" if is_admin() else "Continue without Admin",
            font=ctk.CTkFont(family="Segoe UI", size=13),
            fg_color=self.card_color, hover_color="#222228",
            text_color="#dddddd",
            width=200, height=44, corner_radius=10,
            command=self.start_main
        ).pack(side="left", padx=6)

        self.add_watermark(frame)

        ctk.CTkLabel(
            frame,
            text="Safe optimizations only  •  No forced driver installs",
            font=ctk.CTkFont(family="Segoe UI", size=11),
            text_color="#444"
        ).pack(side="bottom", pady=14)

    def elevate_and_restart(self):
        run_as_admin()

    def start_main(self):
        self.clear_window()
        frame = ctk.CTkFrame(self, fg_color=self.bg_color)
        frame.pack(fill="both", expand=True)

        ctk.CTkLabel(
            frame, text="MQ TWEAKS",
            font=ctk.CTkFont(family="Segoe UI", size=26, weight="bold"),
            text_color="#ffffff"
        ).pack(pady=(130, 4))

        ctk.CTkFrame(frame, fg_color=self.accent_color, height=2, width=90).pack(pady=(0, 18))

        status_lbl = ctk.CTkLabel(
            frame, text="Initializing...",
            font=ctk.CTkFont(family="Segoe UI", size=13),
            text_color="#888"
        )
        status_lbl.pack(pady=(0, 16))

        progress = ctk.CTkProgressBar(frame, width=300, height=8, progress_color=self.accent_color, fg_color=self.card_color)
        progress.pack()
        progress.set(0)

        percent_lbl = ctk.CTkLabel(
            frame, text="0%",
            font=ctk.CTkFont(family="Segoe UI", size=12, weight="bold"),
            text_color=self.accent_color
        )
        percent_lbl.pack(pady=10)

        self.add_watermark(frame)

        def update_progress(value, text):
            progress.set(value / 100)
            percent_lbl.configure(text=f"{value}%")
            status_lbl.configure(text=text)
            self.update_idletasks()

        def scan():
            try:
                update_progress(10, "Checking administrator rights...")
                time.sleep(0.15)
                update_progress(25, "Detecting GPU...")
                self.gpu_info = get_gpu_info()
                time.sleep(0.2)
                update_progress(50, "Reading CPU information...")
                self.cpu_name = get_cpu_info()
                time.sleep(0.15)
                update_progress(70, "Scanning memory...")
                self.ram_info = get_ram_info()
                time.sleep(0.15)
                update_progress(90, "Preparing interface...")
                time.sleep(0.2)
                update_progress(100, "Ready")
                time.sleep(0.25)
                self.after(0, self.build_main_ui)
            except Exception as e:
                self.after(0, lambda: messagebox.showerror("Scan Error", str(e)))
                self.after(0, self.build_main_ui)

        threading.Thread(target=scan, daemon=True).start()

    def add_watermark(self, parent):
        wm = ctk.CTkLabel(
            parent, text=WATERMARK,
            font=ctk.CTkFont(size=12, weight="bold"),
            text_color="#333344"
        )
        wm.place(relx=0.98, rely=0.98, anchor="se")

    # ---------- MAIN DASHBOARD ----------
    def build_main_ui(self):
        self.clear_window()
        self.configure(fg_color=self.bg_color)

        # Sidebar
        sidebar = ctk.CTkFrame(self, width=210, fg_color=self.sidebar_color, corner_radius=0)
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)

        # App icon + title
        icon_frame = ctk.CTkFrame(sidebar, fg_color="transparent")
        icon_frame.pack(pady=(22, 6))

        try:
            pil_icon = Image.open(ICON_PATH)
            self.app_icon = ctk.CTkImage(light_image=pil_icon, dark_image=pil_icon, size=(48, 48))
            ctk.CTkLabel(icon_frame, image=self.app_icon, text="").pack()
        except Exception:
            pass

        ctk.CTkLabel(
            sidebar, text="MQ TWEAKS",
            font=ctk.CTkFont(family="Segoe UI", size=16, weight="bold"),
            text_color="#ffffff"
        ).pack(pady=(6, 0))
        ctk.CTkFrame(sidebar, fg_color=self.accent_color, height=2, width=70).pack(pady=(4, 4))
        ctk.CTkLabel(
            sidebar, text="Tweaks V2",
            font=ctk.CTkFont(family="Segoe UI", size=11),
            text_color="#666"
        ).pack(pady=(0, 16))

        self.nav_buttons = {}
        self.nav_glows = {}  # left neon bars
        # Cleaner, gaming-tech names
        nav_items = [
            ("dashboard", "Overview"),
            ("processes", "Processes"),
            ("gpu", "Graphics"),
            ("power", "Performance"),
            ("bios", "BIOS"),
            ("extras", "Tools"),
        ]

        for key, label in nav_items:
            row = ctk.CTkFrame(sidebar, fg_color="transparent", height=44)
            row.pack(fill="x", padx=8, pady=2)
            row.pack_propagate(False)

            # Neon glow bar (left accent)
            glow = ctk.CTkFrame(row, width=3, height=28, fg_color="transparent", corner_radius=2)
            glow.place(x=4, rely=0.5, anchor="w")
            self.nav_glows[key] = glow

            btn = ctk.CTkButton(
                row, text=f"  {label}",
                font=ctk.CTkFont(family="Segoe UI", size=13),
                fg_color="transparent", hover_color=self.card_color,
                anchor="w", height=40, text_color="#aaaaaa",
                corner_radius=8,
                command=lambda k=key: self.show_page(k)
            )
            btn.pack(fill="both", expand=True, padx=(10, 4))
            self.nav_buttons[key] = btn

        # Content area
        self.content = ctk.CTkFrame(self, fg_color=self.bg_color, corner_radius=0)
        self.content.pack(side="right", fill="both", expand=True)

        # Fade overlay for transitions
        self.fade_overlay = ctk.CTkFrame(self.content, fg_color=self.bg_color, corner_radius=0)
        self._animating = False

        # Cache for pages so switching is fast
        self.pages = {}
        self.current_page = None

        # Top-right theme / appearance button (neon style)
        self.theme_btn = ctk.CTkButton(
            self, text="◐", width=36, height=36, corner_radius=8,
            font=ctk.CTkFont(size=16),
            fg_color=self.card_color, hover_color=self.accent_color,
            text_color=self.text_color, border_width=1, border_color=self.accent_color,
            command=self.open_theme_menu
        )
        self.theme_btn.place(relx=0.97, rely=0.03, anchor="ne")

        self.add_watermark(self)
        self.show_page("dashboard")
        if UPDATE_CHECK_ON_START and UPDATE_URL:
            self.after(1500, lambda: threading.Thread(target=self._bg_update_check, daemon=True).start())

    def _bg_update_check(self):
        info = check_for_updates(silent=True)
        if info and info.get("update"):
            self.after(0, lambda: self._prompt_update(info))

    def _prompt_update(self, info):
        notes = info.get("notes") or "A new version is available."
        msg = f"Update available: v{info.get('version')}\n\nCurrent: v{VERSION}\n\n{notes}\n\nOpen download page?"
        if messagebox.askyesno("Mq Tweaks Update", msg):
            url = info.get("url") or UPDATE_URL
            if url:
                webbrowser.open(url)

    def check_updates_manual(self):
        if not UPDATE_URL:
            messagebox.showinfo(
                "Updates",
                "No update URL configured yet.\n\n"
                "Set UPDATE_URL in the app config to a version.json link,\n"
                "then rebuild when you release a new version."
            )
            return
        info = check_for_updates(silent=False)
        if not info or info.get("error"):
            messagebox.showwarning("Updates", "Could not reach the update server.")
            return
        if info.get("update"):
            self._prompt_update(info)
        else:
            messagebox.showinfo("Updates", f"You're on the latest version (v{VERSION}).")

    def open_theme_menu(self):
        """In-app appearance panel (no separate window)."""
        if getattr(self, "_theme_panel_open", False):
            self._close_theme_panel()
            return

        self._theme_panel_open = True
        self.theme_panel = ctk.CTkFrame(
            self, fg_color=self.card_color, corner_radius=12,
            border_width=1, border_color=self.accent_color,
            width=240, height=340
        )
        self.theme_panel.place(relx=0.97, rely=0.08, anchor="ne")
        self.theme_panel.pack_propagate(False)

        # Header with icon
        header = ctk.CTkFrame(self.theme_panel, fg_color="transparent")
        header.pack(fill="x", padx=12, pady=(12, 4))
        try:
            pil = Image.open(ICON_PATH).resize((22, 22), Image.Resampling.LANCZOS)
            self._panel_icon = ctk.CTkImage(light_image=pil, dark_image=pil, size=(22, 22))
            ctk.CTkLabel(header, image=self._panel_icon, text="").pack(side="left", padx=(0, 6))
        except Exception:
            pass
        ctk.CTkLabel(header, text="Appearance", font=ctk.CTkFont(family="Segoe UI", size=14, weight="bold"),
                     text_color="#ffffff").pack(side="left")
        ctk.CTkButton(header, text="✕", width=28, height=28, fg_color="transparent",
                      hover_color="#333", command=self._close_theme_panel).pack(side="right")

        ctk.CTkLabel(self.theme_panel, text="Theme", font=ctk.CTkFont(family="Segoe UI", size=12, weight="bold"),
                     text_color=self.accent_color).pack(anchor="w", padx=14, pady=(8, 4))

        for name in self.THEMES:
            color = self.THEMES[name]["accent"]
            ctk.CTkButton(
                self.theme_panel, text=name, width=200, height=32,
                font=ctk.CTkFont(family="Segoe UI", size=12),
                fg_color=color if name == self.current_theme else self.bg_color,
                hover_color=color,
                text_color="#000" if name == self.current_theme else self.text_color,
                command=lambda n=name: self.change_theme(n)
            ).pack(pady=2)

        ctk.CTkLabel(self.theme_panel, text="Window", font=ctk.CTkFont(family="Segoe UI", size=12, weight="bold"),
                     text_color=self.accent_color).pack(anchor="w", padx=14, pady=(12, 4))

        trans_text = "Transparency: ON" if self.transparent else "Transparency: OFF"
        self.trans_btn = ctk.CTkButton(
            self.theme_panel, text=trans_text, width=200, height=32,
            font=ctk.CTkFont(family="Segoe UI", size=12),
            fg_color=self.bg_color, hover_color=self.accent_color,
            command=self.toggle_transparency
        )
        self.trans_btn.pack(pady=2)

    def _close_theme_panel(self):
        self._theme_panel_open = False
        if hasattr(self, "theme_panel") and self.theme_panel.winfo_exists():
            self.theme_panel.destroy()

    def change_theme(self, name, menu=None):
        self.current_theme = name
        self.apply_theme_colors()
        self.config_data["theme"] = name
        save_config(self.config_data)
        self._close_theme_panel()
        self.pages = {}
        self.current_page = None
        self.build_main_ui()

    def toggle_transparency(self, menu=None):
        self.transparent = not self.transparent
        self.attributes("-alpha", 0.92 if self.transparent else 1.0)
        self.config_data["transparent"] = self.transparent
        save_config(self.config_data)
        if hasattr(self, "trans_btn") and self.trans_btn.winfo_exists():
            self.trans_btn.configure(text="Transparency: ON" if self.transparent else "Transparency: OFF")

    def show_page(self, page):
        if page == self.current_page or self._animating:
            return

        # Update neon nav glow immediately
        self._set_active_nav(page)

        # Smooth fade transition
        self._animating = True
        self._fade_transition(page)

    def _set_active_nav(self, page):
        for k, btn in self.nav_buttons.items():
            if k == page:
                btn.configure(
                    fg_color=self.card_color,
                    text_color="#ffffff",
                    border_width=0
                )
                if k in self.nav_glows:
                    self.nav_glows[k].configure(fg_color=self.accent_color)
            else:
                btn.configure(
                    fg_color="transparent",
                    text_color="#888888"
                )
                if k in self.nav_glows:
                    self.nav_glows[k].configure(fg_color="transparent")

    def _fade_transition(self, page):
        """Smooth fade transition with neon accent flash."""
        # Clear previous overlay children
        for w in self.fade_overlay.winfo_children():
            w.destroy()

        self.fade_overlay.configure(fg_color=self.bg_color)
        self.fade_overlay.place(relx=0, rely=0, relwidth=1, relheight=1)
        self.fade_overlay.lift()

        # Neon accent line that sweeps
        glow_line = ctk.CTkFrame(self.fade_overlay, fg_color=self.accent_color, height=2, width=1)
        glow_line.place(relx=0.5, rely=0.5, anchor="center")

        steps = 10
        delay = 10  # ~100fps feel

        def fade_out(step=0):
            if step >= steps:
                self._switch_page_content(page)
                # Reset line
                try:
                    glow_line.configure(width=40)
                    glow_line.place(relx=0.5, rely=0.48, anchor="center")
                except Exception:
                    pass
                fade_in(0)
                return
            # Expand neon line
            w = 20 + step * 40
            try:
                glow_line.configure(width=w)
            except Exception:
                pass
            self.update_idletasks()
            self.after(delay, lambda: fade_out(step + 1))

        def fade_in(step=0):
            if step >= steps:
                try:
                    self.fade_overlay.place_forget()
                except Exception:
                    pass
                self._animating = False
                return
            # Shrink / fade neon
            w = max(1, 400 - step * 40)
            try:
                glow_line.configure(width=w)
            except Exception:
                pass
            self.update_idletasks()
            self.after(delay, lambda: fade_in(step + 1))

        fade_out()

    def _switch_page_content(self, page):
        # Hide previous
        if self.current_page and self.current_page in self.pages:
            self.pages[self.current_page].pack_forget()

        # Create if needed — same smooth scroll feel as the Processes list
        if page not in self.pages:
            if page == "processes":
                # Processes has its own internal list scrollbar
                frame = ctk.CTkFrame(self.content, fg_color=self.bg_color, corner_radius=0)
            else:
                frame = ctk.CTkScrollableFrame(
                    self.content,
                    fg_color=self.bg_color,
                    corner_radius=0,
                    scrollbar_button_color=self.card_color,
                    scrollbar_button_hover_color=self.accent_color,
                )
            self.pages[page] = frame

            old_content = self.content
            self.content = frame

            if page == "dashboard":
                self.page_dashboard()
            elif page == "processes":
                self.page_processes()
            elif page == "gpu":
                self.page_gpu()
            elif page == "power":
                self.page_power()
            elif page == "bios":
                self.page_bios()
            elif page == "extras":
                self.page_extras()

            self.content = old_content

        self.pages[page].pack(fill="both", expand=True)
        self.current_page = page
        self.fade_overlay.lift()

    # ---------- DASHBOARD ----------
    def page_dashboard(self):
        # Consistent page padding
        PAD = 32

        header = ctk.CTkLabel(
            self.content, text="Overview",
            font=ctk.CTkFont(family="Segoe UI", size=20, weight="bold"),
            text_color=self.text_color
        )
        header.pack(anchor="w", padx=PAD, pady=(20, 12))

        # Hardware cards — equal width, comfortable spacing
        cards = ctk.CTkFrame(self.content, fg_color="transparent")
        cards.pack(fill="x", padx=PAD - 4, pady=0)
        for c in range(3):
            cards.grid_columnconfigure(c, weight=1, uniform="cards")

        gpu_name = self.gpu_info.get("name", "Unknown")
        cpu_short = self.cpu_name or "Unknown CPU"
        if len(cpu_short) > 34:
            cpu_short = cpu_short[:32] + "…"
        if len(gpu_name) > 30:
            gpu_name = gpu_name[:28] + "…"

        phys = psutil.cpu_count(logical=False) or 1
        logi = psutil.cpu_count() or 1
        mem = psutil.virtual_memory()

        card_specs = [
            ("GPU", gpu_name, f"{self.gpu_info.get('vendor', '')}  ·  Driver {self.gpu_info.get('driver', '?')}"),
            ("CPU", cpu_short, f"{phys} cores  ·  {logi} threads"),
            ("RAM", f"{mem.total / (1024**3):.1f} GB", f"{mem.percent:.0f}% used"),
        ]

        self.dash_value_labels = {}
        self.dash_sub_labels = {}

        for i, (title, value, sub) in enumerate(card_specs):
            card = ctk.CTkFrame(
                cards, fg_color=self.card_color, corner_radius=12,
                border_width=1, border_color="#252530", height=118
            )
            card.grid(row=0, column=i, sticky="nsew", padx=6, pady=2)
            card.grid_propagate(False)

            inner = ctk.CTkFrame(card, fg_color="transparent")
            inner.pack(fill="both", expand=True, padx=18, pady=14)

            ctk.CTkFrame(inner, fg_color=self.accent_color, height=2, width=32).pack(anchor="w")
            ctk.CTkLabel(
                inner, text=title,
                font=ctk.CTkFont(family="Segoe UI", size=11),
                text_color="#6e6e80"
            ).pack(anchor="w", pady=(10, 0))
            val_lbl = ctk.CTkLabel(
                inner, text=value,
                font=ctk.CTkFont(family="Segoe UI", size=15, weight="bold"),
                text_color=self.text_color, wraplength=210, justify="left", anchor="w"
            )
            val_lbl.pack(anchor="w", pady=(6, 0), fill="x")
            sub_lbl = ctk.CTkLabel(
                inner, text=sub,
                font=ctk.CTkFont(family="Segoe UI", size=11),
                text_color=self.accent_color, anchor="w"
            )
            sub_lbl.pack(anchor="w", pady=(8, 0))

            self.dash_value_labels[title] = val_lbl
            self.dash_sub_labels[title] = sub_lbl

        # Live resource monitor
        mon = ctk.CTkFrame(self.content, fg_color=self.card_color, corner_radius=10)
        mon.pack(fill="x", padx=PAD, pady=(14, 0))
        mon_inner = ctk.CTkFrame(mon, fg_color="transparent")
        mon_inner.pack(fill="x", padx=18, pady=10)

        font_mon = ctk.CTkFont(family="Segoe UI", size=12)
        self.cpu_usage_lbl = ctk.CTkLabel(mon_inner, text="CPU  —%", font=font_mon, text_color=self.text_color)
        self.cpu_usage_lbl.pack(side="left", padx=(0, 28))
        self.ram_usage_lbl = ctk.CTkLabel(mon_inner, text="RAM  —%", font=font_mon, text_color=self.text_color)
        self.ram_usage_lbl.pack(side="left", padx=(0, 28))
        self.ram_avail_lbl = ctk.CTkLabel(mon_inner, text="Free  — GB", font=font_mon, text_color="#777")
        self.ram_avail_lbl.pack(side="left")

        self._start_resource_monitor()

        # Quick Actions
        ctk.CTkLabel(
            self.content, text="Quick Actions",
            font=ctk.CTkFont(family="Segoe UI", size=13, weight="bold"),
            text_color="#b0b0c0"
        ).pack(anchor="w", padx=PAD, pady=(18, 8))

        actions = ctk.CTkFrame(self.content, fg_color="transparent")
        actions.pack(fill="x", padx=PAD - 2)

        def qbtn(parent, text, cmd, primary=False):
            return ctk.CTkButton(
                parent, text=text, height=36, corner_radius=8,
                font=ctk.CTkFont(family="Segoe UI", size=12),
                fg_color=self.accent_color if primary else self.card_color,
                hover_color=self.accent_color,
                text_color="#ffffff" if primary else self.text_color,
                command=cmd
            )

        qbtn(actions, "Force All Cores", self.force_all_cores, primary=True).pack(side="left", padx=5)
        qbtn(actions, "RAM Clean", self.ram_clean).pack(side="left", padx=5)
        qbtn(actions, "High Performance", self.apply_high_performance).pack(side="left", padx=5)
        qbtn(actions, "Ultimate Perf", self.apply_ultimate_performance).pack(side="left", padx=5)

        actions2 = ctk.CTkFrame(self.content, fg_color="transparent")
        actions2.pack(fill="x", padx=PAD - 2, pady=(8, 0))
        qbtn(actions2, "Clean Temp", self.clean_temp).pack(side="left", padx=5)
        qbtn(actions2, "Disable Game DVR", self.disable_game_dvr).pack(side="left", padx=5)
        qbtn(actions2, "Flush DNS", self.flush_dns).pack(side="left", padx=5)
        qbtn(actions2, "Power Plans", self.open_power_options).pack(side="left", padx=5)
        qbtn(actions2, "Processes", lambda: self.show_page("processes")).pack(side="left", padx=5)

        status_frame = ctk.CTkFrame(self.content, fg_color=self.card_color, corner_radius=10)
        status_frame.pack(fill="x", padx=PAD, pady=(16, 12))
        admin_txt = "Admin privileges: Active" if is_admin() else "Admin privileges: Missing (some features limited)"
        ctk.CTkLabel(
            status_frame, text=admin_txt,
            font=ctk.CTkFont(family="Segoe UI", size=12),
            text_color="#22c55e" if is_admin() else "#f59e0b"
        ).pack(anchor="w", padx=16, pady=10)

    # ---------- PROCESSES ----------
    def page_processes(self):
        header = ctk.CTkLabel(
            self.content, text="Processes",
            font=ctk.CTkFont(family="Segoe UI", size=22, weight="bold"),
            text_color=self.text_color
        )
        header.pack(anchor="w", padx=28, pady=(20, 4))

        ctk.CTkLabel(
            self.content,
            text="Top CPU & RAM users. Protected apps are never closed.",
            font=ctk.CTkFont(family="Segoe UI", size=12), text_color="#888"
        ).pack(anchor="w", padx=28, pady=(0, 10))

        # Protected apps — add / remove / save
        prot_frame = ctk.CTkFrame(self.content, fg_color=self.card_color, corner_radius=10)
        prot_frame.pack(fill="x", padx=24, pady=4)

        ctk.CTkLabel(prot_frame, text="Protected apps (never closed)",
                     font=ctk.CTkFont(family="Segoe UI", size=12, weight="bold")).pack(anchor="w", padx=14, pady=(10, 2))

        entry_row = ctk.CTkFrame(prot_frame, fg_color="transparent")
        entry_row.pack(fill="x", padx=10, pady=4)

        self.prot_entry = ctk.CTkEntry(
            entry_row, placeholder_text="Add exe  e.g. Discord.exe", width=240,
            font=ctk.CTkFont(family="Segoe UI", size=12)
        )
        self.prot_entry.pack(side="left", padx=(4, 6), pady=6)
        self.prot_entry.bind("<Return>", lambda e: self.add_protected())

        ctk.CTkButton(entry_row, text="Add", width=60, height=30,
                      fg_color=self.accent_color, command=self.add_protected).pack(side="left", pady=6)
        ctk.CTkButton(entry_row, text="Remove", width=70, height=30,
                      fg_color="#444", hover_color="#ef4444",
                      command=self.remove_protected).pack(side="left", padx=4, pady=6)
        ctk.CTkButton(entry_row, text="Save", width=70, height=30,
                      fg_color="#22c55e", hover_color="#16a34a",
                      command=self.save_protected).pack(side="left", padx=4, pady=6)

        self.prot_listbox = ctk.CTkScrollableFrame(prot_frame, fg_color=self.bg_color, height=72, corner_radius=8)
        self.prot_listbox.pack(fill="x", padx=14, pady=(2, 10))
        self.prot_selected = None
        self._refresh_prot_list()

        # Loading area + list container
        self.proc_container = ctk.CTkFrame(self.content, fg_color="transparent")
        self.proc_container.pack(fill="both", expand=True, padx=24, pady=6)

        # Show loading first
        self._show_proc_loading()

        btn_row = ctk.CTkFrame(self.content, fg_color="transparent")
        btn_row.pack(fill="x", padx=24, pady=6)
        ctk.CTkButton(btn_row, text="Refresh", width=100, height=32,
                      font=ctk.CTkFont(family="Segoe UI", size=12),
                      command=self._show_proc_loading).pack(side="left", padx=4)
        ctk.CTkButton(btn_row, text="Kill Selected", width=130, height=32,
                      font=ctk.CTkFont(family="Segoe UI", size=12),
                      fg_color="#ef4444", hover_color="#dc2626",
                      command=self.kill_selected).pack(side="left", padx=6)

    def _show_proc_loading(self):
        for w in self.proc_container.winfo_children():
            w.destroy()

        load_frame = ctk.CTkFrame(self.proc_container, fg_color=self.card_color, corner_radius=12)
        load_frame.pack(fill="both", expand=True, pady=6)

        ctk.CTkLabel(
            load_frame, text="PLEASE WAIT",
            font=ctk.CTkFont(family="Segoe UI", size=14, weight="bold"),
            text_color="#cccccc"
        ).pack(pady=(50, 12))

        self.proc_progress = ctk.CTkProgressBar(
            load_frame, width=280, height=10,
            progress_color=self.accent_color, fg_color="#2a2a30"
        )
        self.proc_progress.pack()
        self.proc_progress.set(0)

        self.proc_pct = ctk.CTkLabel(
            load_frame, text="0%",
            font=ctk.CTkFont(family="Segoe UI", size=12),
            text_color="#888"
        )
        self.proc_pct.pack(pady=8)

        self.proc_status = ctk.CTkLabel(
            load_frame, text="Loading processes...",
            font=ctk.CTkFont(family="Segoe UI", size=11),
            text_color="#555"
        )
        self.proc_status.pack(pady=(0, 20))

        threading.Thread(target=self._scan_processes_bg, daemon=True).start()

    def _scan_processes_bg(self):
        """Reliable process scan — always finishes."""
        try:
            self.after(0, lambda: self._set_proc_progress(10, "Scanning..."))
            time.sleep(0.15)

            procs = []
            # One pass only — fast and stable
            for p in psutil.process_iter(["pid", "name", "memory_info"]):
                try:
                    info = p.info
                    if not info.get("name") or not info.get("memory_info"):
                        continue
                    mem_mb = info["memory_info"].rss / (1024 * 1024)
                    if mem_mb < 30:
                        continue
                    try:
                        cpu = p.cpu_percent(interval=None) or 0
                    except Exception:
                        cpu = 0
                    procs.append({
                        "pid": info["pid"],
                        "name": info["name"],
                        "cpu": cpu,
                        "mem": mem_mb
                    })
                except (psutil.NoSuchProcess, psutil.AccessDenied, Exception):
                    continue

            self.after(0, lambda: self._set_proc_progress(70, "Sorting..."))
            time.sleep(0.1)

            procs.sort(key=lambda x: x["mem"], reverse=True)
            procs = procs[:40]

            self.after(0, lambda: self._set_proc_progress(100, "Done"))
            time.sleep(0.12)
            self.after(0, lambda: self._render_process_list(procs))
        except Exception as e:
            # Never stay stuck — show empty list + error
            self.after(0, lambda: self._set_proc_progress(100, "Error"))
            self.after(0, lambda: self._render_process_list([]))
            self.after(0, lambda: messagebox.showerror("Process scan", str(e)))

    def _set_proc_progress(self, value, text=None):
        try:
            if hasattr(self, "proc_progress") and self.proc_progress.winfo_exists():
                self.proc_progress.set(max(0, min(1, value / 100)))
            if hasattr(self, "proc_pct") and self.proc_pct.winfo_exists():
                self.proc_pct.configure(text=f"{int(value)}%")
            if text and hasattr(self, "proc_status") and self.proc_status.winfo_exists():
                self.proc_status.configure(text=text)
        except Exception:
            pass

    def _render_process_list(self, procs):
        for w in self.proc_container.winfo_children():
            w.destroy()

        list_frame = ctk.CTkScrollableFrame(self.proc_container, fg_color=self.sidebar_color, height=300)
        list_frame.pack(fill="both", expand=True)

        header_row = ctk.CTkFrame(list_frame, fg_color="transparent")
        header_row.pack(fill="x", pady=(4, 6))
        for txt, w in [("Process", 210), ("CPU %", 65), ("RAM MB", 75), ("PID", 65), ("", 80)]:
            ctk.CTkLabel(header_row, text=txt, width=w, anchor="w",
                         font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"),
                         text_color="#666").pack(side="left")

        self.proc_rows = []
        self.selected_pids = set()

        for proc in procs:
            row = ctk.CTkFrame(list_frame, fg_color=self.card_color, corner_radius=6, height=32)
            row.pack(fill="x", pady=1)
            row.pack_propagate(False)

            is_protected = proc["name"].lower() in {a.lower() for a in self.protected}
            name_color = "#22c55e" if is_protected else self.text_color

            ctk.CTkLabel(row, text=proc["name"][:30], width=210, anchor="w",
                         font=ctk.CTkFont(family="Segoe UI", size=12),
                         text_color=name_color).pack(side="left", padx=(8, 0))
            ctk.CTkLabel(row, text=f"{proc['cpu']:.1f}", width=65, anchor="w",
                         font=ctk.CTkFont(family="Segoe UI", size=12)).pack(side="left")
            ctk.CTkLabel(row, text=f"{proc['mem']:.0f}", width=75, anchor="w",
                         font=ctk.CTkFont(family="Segoe UI", size=12)).pack(side="left")
            ctk.CTkLabel(row, text=str(proc["pid"]), width=65, anchor="w",
                         font=ctk.CTkFont(family="Segoe UI", size=11), text_color="#666").pack(side="left")

            if not is_protected:
                var = tk.BooleanVar(value=False)
                cb = ctk.CTkCheckBox(row, text="", variable=var, width=28,
                                     command=lambda p=proc["pid"], v=var: self.toggle_select(p, v))
                cb.pack(side="left", padx=8)
            else:
                ctk.CTkLabel(row, text="safe", text_color="#22c55e",
                             font=ctk.CTkFont(family="Segoe UI", size=10)).pack(side="left", padx=6)

            self.proc_rows.append(row)

    def toggle_select(self, pid, var):
        if var.get():
            self.selected_pids.add(pid)
        else:
            self.selected_pids.discard(pid)

    def _refresh_prot_list(self):
        if not hasattr(self, "prot_listbox"):
            return
        for w in self.prot_listbox.winfo_children():
            w.destroy()
        self.prot_selected = None
        for name in sorted(self.protected, key=str.lower):
            row = ctk.CTkFrame(self.prot_listbox, fg_color="transparent", height=26)
            row.pack(fill="x", pady=1)
            btn = ctk.CTkButton(
                row, text=name, anchor="w", height=24,
                font=ctk.CTkFont(family="Segoe UI", size=11),
                fg_color="transparent", hover_color=self.card_color,
                text_color=self.text_color,
                command=lambda n=name: self._select_prot(n)
            )
            btn.pack(fill="x", padx=4)

    def _select_prot(self, name):
        self.prot_selected = name
        self.prot_entry.delete(0, "end")
        self.prot_entry.insert(0, name)

    def add_protected(self):
        name = self.prot_entry.get().strip()
        if not name:
            return
        if not name.lower().endswith(".exe"):
            name += ".exe"
        self.protected.add(name)
        self.prot_entry.delete(0, "end")
        self._refresh_prot_list()

    def remove_protected(self):
        name = self.prot_selected or self.prot_entry.get().strip()
        if not name:
            messagebox.showinfo("Protected", "Select or type an app to remove.")
            return
        if not name.lower().endswith(".exe"):
            name += ".exe"
        # Case-insensitive remove
        to_remove = [p for p in self.protected if p.lower() == name.lower()]
        if not to_remove:
            messagebox.showinfo("Protected", f"{name} is not in the list.")
            return
        for p in to_remove:
            self.protected.discard(p)
        self.prot_selected = None
        self.prot_entry.delete(0, "end")
        self._refresh_prot_list()

    def save_protected(self):
        self.config_data["protected_apps"] = list(self.protected)
        save_config(self.config_data)
        messagebox.showinfo("Saved", f"Protected list saved ({len(self.protected)} apps).")

    def kill_selected(self):
        if not self.selected_pids:
            messagebox.showwarning("None selected", "Select some processes first.")
            return
        if not messagebox.askyesno("Confirm", f"Kill {len(self.selected_pids)} selected processes?"):
            return
        killed = 0
        for pid in list(self.selected_pids):
            try:
                p = psutil.Process(pid)
                if p.name().lower() not in {a.lower() for a in self.protected}:
                    p.terminate()
                    killed += 1
            except Exception:
                pass
        messagebox.showinfo("Done", f"Terminated {killed} processes.")
        self.selected_pids.clear()

    # ---------- GPU & DRIVERS ----------
    def page_gpu(self):
        header = ctk.CTkLabel(self.content, text="Graphics", font=ctk.CTkFont(family="Segoe UI", size=22, weight="bold"), text_color=self.text_color)
        header.pack(anchor="w", padx=30, pady=(20, 10))

        info_card = ctk.CTkFrame(self.content, fg_color="#1a1a22", corner_radius=12)
        info_card.pack(fill="x", padx=25, pady=8)

        ctk.CTkLabel(info_card, text=f"Detected: {self.gpu_info['vendor']}", font=ctk.CTkFont(size=14, weight="bold"), text_color="#00d4ff").pack(anchor="w", padx=18, pady=(14, 2))
        ctk.CTkLabel(info_card, text=self.gpu_info["name"], font=ctk.CTkFont(size=15)).pack(anchor="w", padx=18)
        ctk.CTkLabel(info_card, text=f"Driver: {self.gpu_info['driver']}", font=ctk.CTkFont(size=13), text_color="#888").pack(anchor="w", padx=18, pady=(2, 14))

        # Actions
        act = ctk.CTkFrame(self.content, fg_color="transparent")
        act.pack(fill="x", padx=25, pady=15)

        if self.gpu_info["vendor"] == "NVIDIA":
            ctk.CTkButton(act, text="Open NVIDIA Driver Download", width=240, height=42,
                          fg_color="#76b900", hover_color="#5a8f00",
                          command=lambda: webbrowser.open("https://www.nvidia.com/Download/index.aspx")).pack(side="left", padx=6)
            ctk.CTkButton(act, text="Open NVIDIA App", width=180, height=42,
                          command=self.try_open_nvidia_app).pack(side="left", padx=6)
        elif self.gpu_info["vendor"] == "AMD":
            ctk.CTkButton(act, text="Open AMD Driver Download", width=240, height=42,
                          fg_color="#ed1c24", hover_color="#c4161c",
                          command=lambda: webbrowser.open("https://www.amd.com/en/support")).pack(side="left", padx=6)
        else:
            ctk.CTkButton(act, text="Search Drivers (Intel/Other)", width=220, height=42,
                          command=lambda: webbrowser.open("https://www.google.com/search?q=graphics+driver+download")).pack(side="left", padx=6)

        # Recommended settings
        ctk.CTkLabel(self.content, text="Recommended NVIDIA / AMD Settings for Max FPS",
                     font=ctk.CTkFont(size=15, weight="bold")).pack(anchor="w", padx=30, pady=(20, 8))

        settings_box = ctk.CTkTextbox(self.content, height=220, fg_color="#1a1a22", font=ctk.CTkFont(family="Consolas", size=13))
        settings_box.pack(fill="x", padx=25, pady=5)

        nvidia_tips = """NVIDIA Control Panel → Manage 3D Settings (Global):
• Power management mode          → Prefer maximum performance
• Low Latency Mode               → Ultra
• Maximum Pre-Rendered Frames    → 1
• Texture filtering - Quality    → High performance
• Vertical Sync                  → Off
• Antialiasing - Mode            → Off (or Application-controlled)
• Threaded optimization          → On
• Shader Cache Size              → Unlimited

Also enable NVIDIA Reflex in supported games (Fortnite, etc.).
For advanced users: Use NVIDIA Profile Inspector + import a good .nip."""

        amd_tips = """AMD Software → Gaming → Graphics:
• Radeon Anti-Lag                → Enabled
• Radeon Chill                    → Disabled
• Radeon Boost                    → Disabled (or test)
• Radeon Image Sharpening         → Off or low
• Texture Filtering Quality       → Performance
• Wait for Vertical Refresh       → Always Off
• Tessellation Mode               → Override → 8x or lower

Use "eSports" or "Esports" preset if available."""

        if self.gpu_info["vendor"] == "AMD":
            settings_box.insert("1.0", amd_tips)
        else:
            settings_box.insert("1.0", nvidia_tips)
        settings_box.configure(state="disabled")

        ctk.CTkButton(self.content, text="Generate NVIDIA .nip (Profile Inspector)", width=280,
                      command=self.generate_nip).pack(anchor="w", padx=30, pady=12)

    def try_open_nvidia_app(self):
        paths = [
            r"C:\Program Files\NVIDIA Corporation\NVIDIA App\CEF\NVIDIA App.exe",
            r"C:\Program Files\NVIDIA Corporation\NVIDIA App\CEF\NVIDIA_App.exe",
            r"C:\Program Files\NVIDIA Corporation\NVIDIA app\CEF\NVIDIA App.exe",
            r"C:\Program Files\NVIDIA Corporation\NVIDIA App\NVIDIA App.exe",
            r"C:\Program Files\NVIDIA Corporation\NVIDIA GeForce Experience\NVIDIA GeForce Experience.exe",
            r"C:\Program Files (x86)\NVIDIA Corporation\NVIDIA GeForce Experience\NVIDIA GeForce Experience.exe",
        ]
        for p in paths:
            if os.path.exists(p):
                subprocess.Popen([p], shell=False)
                return
        # Fallback: search common folder
        base = r"C:\Program Files\NVIDIA Corporation"
        if os.path.isdir(base):
            for root, dirs, files in os.walk(base):
                for f in files:
                    if f.lower() in ("nvidia app.exe", "nvidia_app.exe", "nvidia geForce experience.exe"):
                        full = os.path.join(root, f)
                        subprocess.Popen([full], shell=False)
                        return
        messagebox.showinfo("Not found", "NVIDIA App not found.\nInstall it from the official NVIDIA website.")

    def generate_nip(self):
        """Create a basic recommended .nip for NVIDIA Profile Inspector"""
        nip_content = '''<?xml version="1.0" encoding="utf-16"?>
<ArrayOfProfile>
  <Profile>
    <ProfileName>mquf Global Performance</ProfileName>
    <Executeables />
    <Settings>
      <ProfileSetting>
        <SettingNameInfo>Power management mode</SettingNameInfo>
        <SettingID>1053613614</SettingID>
        <SettingValue>1</SettingValue>
      </ProfileSetting>
      <ProfileSetting>
        <SettingNameInfo>Maximum pre-rendered frames</SettingNameInfo>
        <SettingID>8102046</SettingID>
        <SettingValue>1</SettingValue>
      </ProfileSetting>
      <ProfileSetting>
        <SettingNameInfo>Low Latency Mode</SettingNameInfo>
        <SettingID>2776260686</SettingID>
        <SettingValue>2</SettingValue>
      </ProfileSetting>
      <ProfileSetting>
        <SettingNameInfo>Texture filtering - Quality</SettingNameInfo>
        <SettingID>13510289</SettingID>
        <SettingValue>0</SettingValue>
      </ProfileSetting>
      <ProfileSetting>
        <SettingNameInfo>Vertical Sync</SettingNameInfo>
        <SettingID>11041231</SettingID>
        <SettingValue>0</SettingValue>
      </ProfileSetting>
    </Settings>
  </Profile>
</ArrayOfProfile>'''
        path = filedialog.asksaveasfilename(defaultextension=".nip", filetypes=[("NVIDIA Profile", "*.nip")],
                                            initialfile="mquf_performance.nip")
        if path:
            with open(path, "w", encoding="utf-16") as f:
                f.write(nip_content)
            messagebox.showinfo("Saved", f"Saved to:\n{path}\n\nImport this with NVIDIA Profile Inspector\n(https://github.com/Orbmu2k/nvidiaProfileInspector)")

    # ---------- POWER PLAN ----------
    def page_power(self):
        header = ctk.CTkLabel(self.content, text="Performance", font=ctk.CTkFont(family="Segoe UI", size=22, weight="bold"), text_color=self.text_color)
        header.pack(anchor="w", padx=30, pady=(20, 10))

        ctk.CTkLabel(self.content,
                     text="High Performance / Ultimate Performance unlocks higher sustained clocks.",
                     font=ctk.CTkFont(size=13), text_color="#888").pack(anchor="w", padx=30)

        card = ctk.CTkFrame(self.content, fg_color="#1a1a22", corner_radius=12)
        card.pack(fill="x", padx=25, pady=20)

        ctk.CTkButton(card, text="Activate High Performance", width=260, height=44,
                      fg_color="#00d4ff", hover_color="#00a8cc", text_color="#000",
                      command=self.apply_high_performance).pack(pady=(20, 8), padx=20)

        ctk.CTkButton(card, text="Activate Ultimate Performance (recommended)", width=320, height=44,
                      fg_color="#8b5cf6", hover_color="#7c3aed",
                      command=self.apply_ultimate_performance).pack(pady=8, padx=20)

        ctk.CTkButton(card, text="Open Choose a Power Plan", width=240, height=38,
                      fg_color="#2a2a35", command=self.open_power_options).pack(pady=(8, 20), padx=20)

        note = ctk.CTkLabel(self.content,
                            text="Note: Ultimate Performance is hidden by default. The button will unlock + activate it.\nRequires Administrator.",
                            font=ctk.CTkFont(size=12), text_color="#666")
        note.pack(anchor="w", padx=30, pady=10)

    def open_power_options(self):
        """Open the classic 'Choose a power plan' Control Panel page."""
        try:
            subprocess.Popen(["control.exe", "powercfg.cpl"], shell=False)
        except Exception:
            try:
                os.startfile("powercfg.cpl")
            except Exception as e:
                messagebox.showerror("Error", f"Could not open Power Options:\n{e}")

    def apply_high_performance(self):
        if not is_admin():
            messagebox.showwarning("Admin needed", "Run the app as Administrator to change power plans.")
            return
        try:
            # Ensure it exists
            subprocess.run(["powercfg", "-duplicatescheme", HIGH_PERF_GUID], capture_output=True,
                           creationflags=subprocess.CREATE_NO_WINDOW)
            # Activate
            subprocess.run(["powercfg", "/setactive", HIGH_PERF_GUID], check=True,
                           creationflags=subprocess.CREATE_NO_WINDOW)
            messagebox.showinfo("Done", "High Performance power plan activated.")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def apply_ultimate_performance(self):
        if not is_admin():
            messagebox.showwarning("Admin needed", "Run the app as Administrator.")
            return
        try:
            # Unlock
            result = subprocess.run(["powercfg", "-duplicatescheme", ULTIMATE_PERF_GUID],
                                    capture_output=True, text=True, creationflags=subprocess.CREATE_NO_WINDOW)
            # Find the new GUID from output or just try known
            # Activate the ultimate one
            subprocess.run(["powercfg", "/setactive", ULTIMATE_PERF_GUID], check=True,
                           creationflags=subprocess.CREATE_NO_WINDOW)
            messagebox.showinfo("Done", "Ultimate Performance activated.\nYour CPU/GPU can now sustain higher clocks.")
        except Exception as e:
            # Sometimes the GUID after duplicate is different – fall back to high
            try:
                subprocess.run(["powercfg", "/setactive", HIGH_PERF_GUID], check=True,
                               creationflags=subprocess.CREATE_NO_WINDOW)
                messagebox.showinfo("Partial", "Ultimate may already exist or failed. High Performance set instead.")
            except Exception as e2:
                messagebox.showerror("Error", str(e2))

    # ---------- BIOS TIPS ----------
    def page_bios(self):
        header = ctk.CTkLabel(self.content, text="BIOS", font=ctk.CTkFont(family="Segoe UI", size=22, weight="bold"), text_color=self.text_color)
        header.pack(anchor="w", padx=30, pady=(20, 8))

        ctk.CTkLabel(self.content,
                     text="These are manual changes. Never update BIOS unless necessary and from official motherboard site.",
                     font=ctk.CTkFont(size=13), text_color="#f59e0b").pack(anchor="w", padx=30, pady=(0, 12))

        tips = ctk.CTkTextbox(self.content, height=420, fg_color="#1a1a22", font=ctk.CTkFont(size=13))
        tips.pack(fill="both", expand=True, padx=25, pady=5)

        content = f"""Detected CPU: {self.cpu_name}

RECOMMENDED BIOS SETTINGS FOR GAMING / FPS:

1. Memory (very important)
   • Enable XMP / DOCP / EXPO profile (run RAM at rated speed)
   • If unstable, try the next lower profile

2. Resizable BAR / Smart Access Memory
   • Enable Above 4G Decoding + Re-Size BAR Support
   • Gives free FPS on modern NVIDIA/AMD GPUs

3. CPU
   • Intel: Ensure all Performance cores are enabled
   • Disable "Intel SpeedStep" only if you want max clocks (higher power/heat)
   • Leave C-States enabled for normal use

4. PCIe
   • Set PCIe slot of GPU to Gen4 or Gen5 (match your GPU)
   • ASPM → Disabled (can reduce latency)

5. Other useful
   • Fast Boot → Enabled (or Disabled if you need full POST)
   • Secure Boot → can stay On
   • CSM → Disabled if using UEFI + GPT (better)

BIOS UPDATE ADVICE:
• Only update if you have a specific reason (new CPU support, security fix, major stability)
• Download ONLY from your motherboard manufacturer website
• Use the official tool (USB method or Q-Flash / M-Flash / EZ Flash)
• Never interrupt a BIOS update
• This app will NEVER auto-update your BIOS

How to enter BIOS: usually Del or F2 at boot.
"""
        tips.insert("1.0", content)
        tips.configure(state="disabled")

    # ---------- EXTRAS ----------
    def page_extras(self):
        header = ctk.CTkLabel(self.content, text="Tools", font=ctk.CTkFont(family="Segoe UI", size=22, weight="bold"), text_color=self.text_color)
        header.pack(anchor="w", padx=30, pady=(20, 15))

        def make_action(title, desc, cmd):
            f = ctk.CTkFrame(self.content, fg_color="#1a1a22", corner_radius=10)
            f.pack(fill="x", padx=25, pady=6)
            ctk.CTkLabel(f, text=title, font=ctk.CTkFont(size=14, weight="bold")).pack(anchor="w", padx=16, pady=(12, 2))
            ctk.CTkLabel(f, text=desc, font=ctk.CTkFont(size=12), text_color="#888").pack(anchor="w", padx=16)
            ctk.CTkButton(f, text="Run", width=90, height=32, command=cmd).pack(anchor="e", padx=16, pady=(4, 12))

        make_action("Clean Temp Files", "Deletes files in %TEMP% and Windows Temp folders", self.clean_temp)
        make_action("Disable Game DVR / Game Bar", "Stops background recording that hurts FPS", self.disable_game_dvr)
        make_action("Flush DNS + Reset Network", "Quick network stack reset", self.flush_dns)
        make_action("Open Windows Graphics Settings", "Set High Performance for specific games",
                    lambda: subprocess.Popen("ms-settings:display-advancedgraphics"))
        make_action("Check for Updates", "See if a newer Mq Tweaks build is available", self.check_updates_manual)

    def _on_resize(self, event):
        """Debounce resize events so dragging the window stays smooth."""
        if event.widget != self:
            return
        self._resizing = True
        if self._resize_after:
            try:
                self.after_cancel(self._resize_after)
            except Exception:
                pass
        self._resize_after = self.after(120, self._resize_done)

    def _resize_done(self):
        self._resizing = False
        self._resize_after = None

    def _start_resource_monitor(self):
        """Live CPU/RAM usage on Overview — skips updates while resizing."""
        if getattr(self, "_monitor_running", False):
            return
        self._monitor_running = True

        def tick():
            if not getattr(self, "_monitor_running", False):
                return
            # Skip UI updates during active resize to avoid lag
            if not getattr(self, "_resizing", False):
                try:
                    if hasattr(self, "cpu_usage_lbl") and self.cpu_usage_lbl.winfo_exists():
                        cpu = psutil.cpu_percent(interval=None)
                        mem = psutil.virtual_memory()
                        self.cpu_usage_lbl.configure(text=f"CPU  {cpu:.0f}%")
                        self.ram_usage_lbl.configure(text=f"RAM  {mem.percent:.0f}%")
                        self.ram_avail_lbl.configure(text=f"Free  {mem.available / (1024**3):.1f} GB")
                        if "RAM" in getattr(self, "dash_sub_labels", {}):
                            self.dash_sub_labels["RAM"].configure(text=f"{mem.percent:.0f}% used")
                except Exception:
                    pass
            self.after(2000, tick)

        try:
            psutil.cpu_percent(interval=None)
        except Exception:
            pass
        self.after(800, tick)

    def force_all_cores(self):
        """Force all CPU cores active: disable parking + min processor state 100%."""
        if not is_admin():
            messagebox.showwarning("Admin needed", "Run as Administrator to force all cores.")
            return
        try:
            cmds = [
                # Min/max processor state
                ["powercfg", "/setacvalueindex", "SCHEME_CURRENT", "SUB_PROCESSOR", "PROCTHROTTLEMIN", "100"],
                ["powercfg", "/setacvalueindex", "SCHEME_CURRENT", "SUB_PROCESSOR", "PROCTHROTTLEMAX", "100"],
                ["powercfg", "/setdcvalueindex", "SCHEME_CURRENT", "SUB_PROCESSOR", "PROCTHROTTLEMIN", "100"],
                ["powercfg", "/setdcvalueindex", "SCHEME_CURRENT", "SUB_PROCESSOR", "PROCTHROTTLEMAX", "100"],
                # Core parking (CPMINCORES / unpark)
                ["powercfg", "/setacvalueindex", "SCHEME_CURRENT", "SUB_PROCESSOR", "CPMINCORES", "100"],
                ["powercfg", "/setacvalueindex", "SCHEME_CURRENT", "SUB_PROCESSOR", "CPMAXCORES", "100"],
                ["powercfg", "/setdcvalueindex", "SCHEME_CURRENT", "SUB_PROCESSOR", "CPMINCORES", "100"],
                ["powercfg", "/setdcvalueindex", "SCHEME_CURRENT", "SUB_PROCESSOR", "CPMAXCORES", "100"],
                # Apply
                ["powercfg", "/setactive", "SCHEME_CURRENT"],
            ]
            for c in cmds:
                subprocess.run(c, capture_output=True, creationflags=subprocess.CREATE_NO_WINDOW)
            messagebox.showinfo(
                "Force All Cores",
                "All cores set to stay active.\n"
                "• Processor min state: 100%\n"
                "• Core parking: disabled\n\n"
                "This is not a voltage overclock — it keeps every core available for games."
            )
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def ram_clean(self):
        """Reduce RAM usage: trim working sets of heavy non-protected processes."""
        try:
            before = psutil.virtual_memory().available
            trimmed = 0
            protected = {a.lower() for a in self.protected}
            protected.update({"system", "registry", "smss.exe", "csrss.exe", "wininit.exe",
                              "services.exe", "lsass.exe", "svchost.exe", "explorer.exe",
                              "dwm.exe", "mq_tweaks.exe", "python.exe", "pythonw.exe"})

            for p in psutil.process_iter(["pid", "name", "memory_info"]):
                try:
                    info = p.info
                    name = (info.get("name") or "").lower()
                    if name in protected:
                        continue
                    if not info.get("memory_info"):
                        continue
                    if info["memory_info"].rss < 40 * 1024 * 1024:
                        continue
                    # Empty working set via Windows API
                    try:
                        handle = ctypes.windll.kernel32.OpenProcess(0x1F0FFF, False, info["pid"])
                        if handle:
                            ctypes.windll.psapi.EmptyWorkingSet(handle)
                            ctypes.windll.kernel32.CloseHandle(handle)
                            trimmed += 1
                    except Exception:
                        pass
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue

            # Also clear temp lightly
            temp = os.getenv("TEMP")
            if temp and os.path.isdir(temp):
                for f in os.listdir(temp)[:80]:
                    try:
                        fp = os.path.join(temp, f)
                        if os.path.isfile(fp):
                            os.remove(fp)
                    except Exception:
                        pass

            time.sleep(0.3)
            after = psutil.virtual_memory().available
            freed_mb = max(0, (after - before) / (1024 * 1024))
            messagebox.showinfo(
                "RAM Clean",
                f"Trimmed {trimmed} processes.\n"
                f"Approx. freed: {freed_mb:.0f} MB available RAM gained.\n\n"
                "Protected apps were left alone."
            )
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def clean_temp(self):
        if not messagebox.askyesno("Confirm", "Delete temporary files?"):
            return
        count = 0
        paths = [os.getenv("TEMP"), r"C:\Windows\Temp"]
        for base in paths:
            if not base or not os.path.isdir(base):
                continue
            for root, dirs, files in os.walk(base):
                for f in files:
                    try:
                        os.remove(os.path.join(root, f))
                        count += 1
                    except Exception:
                        pass
        messagebox.showinfo("Done", f"Cleaned approximately {count} temp files.")

    def disable_game_dvr(self):
        if not is_admin():
            messagebox.showwarning("Admin", "Need Administrator rights.")
            return
        try:
            # Disable via registry
            cmds = [
                ['reg', 'add', r'HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\GameDVR', '/v', 'AppCaptureEnabled', '/t', 'REG_DWORD', '/d', '0', '/f'],
                ['reg', 'add', r'HKCU\System\GameConfigStore', '/v', 'GameDVR_Enabled', '/t', 'REG_DWORD', '/d', '0', '/f'],
            ]
            for c in cmds:
                subprocess.run(c, capture_output=True, creationflags=subprocess.CREATE_NO_WINDOW)
            messagebox.showinfo("Done", "Game DVR / Game Bar capture disabled.")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def flush_dns(self):
        try:
            subprocess.run(["ipconfig", "/flushdns"], capture_output=True, creationflags=subprocess.CREATE_NO_WINDOW)
            subprocess.run(["netsh", "winsock", "reset"], capture_output=True, creationflags=subprocess.CREATE_NO_WINDOW)
            messagebox.showinfo("Done", "DNS flushed. A restart may be needed for full effect.")
        except Exception as e:
            messagebox.showerror("Error", str(e))


# ==================== ENTRY ====================
if __name__ == "__main__":
    # On Windows only
    if platform.system() != "Windows":
        print("This tool is designed for Windows.")
        sys.exit(1)

    app = MqufOptimizer()
    app.mainloop()
