# mquf Optimizer

Clean, modern Windows PC optimization tool focused on FPS for games (Fortnite, FiveM, etc.).

**Watermark:** `@mquf`

## Features

1. **Hardware Scan** – Detects GPU (NVIDIA/AMD), CPU, RAM
2. **Power Plan** – One-click High Performance + Ultimate Performance
3. **Process Killer** – Top CPU/RAM consumers with protect list (you choose what never to close)
4. **GPU Tools** – Opens official driver pages + recommended Control Panel settings + generates `.nip` for NVIDIA Profile Inspector
5. **BIOS Tips** – Safe, hardware-aware recommendations (no auto BIOS update – too dangerous)
6. **Extras** – Temp clean, disable Game DVR, DNS flush, etc.
7. **Welcome Loader** – Asks for Admin elevation, shows `@mquf` watermark

## Requirements

- Windows 10 / 11
- Python 3.10+ (only needed to build)
- Administrator rights for full features

## How to Build the .exe (recommended)

1. Open **PowerShell** or **Command Prompt** as normal user
2. Go to this folder:
   ```bash
   cd path\to\mquf_optimizer
   ```
3. Create virtual environment (optional but clean):
   ```bash
   python -m venv venv
   venv\Scripts\activate
   ```
4. Install dependencies:
   ```bash
   pip install -r requirements.txt
   pip install pyinstaller
   ```
5. Build one-file EXE with admin manifest:
   ```bash
   pyinstaller --noconfirm --onefile --windowed --uac-admin --name "mquf_Optimizer" --icon=NONE main.py
   ```
6. The finished `.exe` will be in the `dist` folder:
   ```
   dist\mquf_Optimizer.exe
   ```

### Alternative (simpler command)
```bash
pyinstaller --onefile --noconsole --uac-admin main.py
```

## How to Use

1. Right-click the `.exe` → **Run as administrator** (or the UAC prompt will appear)
2. Welcome screen appears → click **Scan PC • Run as Admin** if needed
3. Use the sidebar to navigate:
   - Dashboard
   - Process Killer (add apps you want protected)
   - GPU & Drivers
   - Power Plan
   - BIOS Tips
   - Extras

## Safety Notes

- Never auto-installs GPU drivers (opens official NVIDIA/AMD pages only)
- Never touches BIOS automatically
- Process killer respects your protected list
- No deep registry nukes
- Game DVR disable is optional and reversible

## Recommended extra tools

- **NVIDIA Profile Inspector**: https://github.com/Orbmu2k/nvidiaProfileInspector  
  (import the generated `.nip`)
- GeForce Experience or AMD Software for driver updates

---

Made for `@mquf`
