@echo off
echo ========================================
echo   Building Mq Tweaks v2.1
echo ========================================
echo.

python -m pip install -r requirements.txt --quiet
python -m pip install pyinstaller --quiet

echo.
echo Closing old Mq_Tweaks if running...
taskkill /f /im Mq_Tweaks.exe >nul 2>&1

echo Cleaning old build...
if exist "dist\Mq_Tweaks.exe" (
    del /f /q "dist\Mq_Tweaks.exe" >nul 2>&1
)
if exist "build" rd /s /q "build" >nul 2>&1
if exist "Mq_Tweaks.spec" del /f /q "Mq_Tweaks.spec" >nul 2>&1

echo.
echo Building with icon...
python -m PyInstaller --noconfirm --onefile --windowed --uac-admin --name "Mq_Tweaks" --add-data "assets;assets" --icon "assets/icon.ico" main.py

echo.
echo ========================================
if exist "dist\Mq_Tweaks.exe" (
    echo SUCCESS!
    echo Your .exe is here: dist\Mq_Tweaks.exe
) else (
    echo BUILD FAILED.
    echo.
    echo If you see "Access is denied":
    echo   1. Close Mq_Tweaks if it is open
    echo   2. Open Task Manager and End task Mq_Tweaks.exe
    echo   3. Delete dist\Mq_Tweaks.exe manually
    echo   4. Run this build.bat again
)
echo ========================================
pause
